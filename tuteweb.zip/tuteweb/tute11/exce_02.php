<!-- http://localhost/PHP1/exce_02.php -->
<?php
// Using a for loop to display count from 5 to 15
for ($i = 5; $i <= 15; $i++) {
    echo $i . "\n";
}
?>